#include <stdio.h>
#include "y.tab.h"
#include "first.h"

struct nnode* nalloc(){
    struct nnode* np = (struct nnode*) malloc(sizeof(struct nnode));
    if (np == NULL){
        yyerror("Out of Memory");
    }
    return np;
}

struct nnode* leaf(int type, int val){
    struct nnode* np = nalloc();
    np->oper = type;
    np->left.value = val;
    np->left.np = NULL;
    np->right.np = NULL;
    np->third.np = NULL;
    return np;
}

struct nnode *node(int op, struct nnode* left, struct nnode* right)
{
	struct nnode *np = nalloc();
	np->oper = op;
	np->left.np = left;
	np->right.np = right;
	np->third.np = NULL;
	return np;
}

struct nnode *triple(int op, struct nnode* left, struct nnode* right, struct nnode* third)
{
	struct nnode *np = nalloc();
	np->oper = op;
	np->left.np = left;
	np->right.np = right;
	np->third.np = third;
	return np;
}

void freeall(struct nnode* n){
    if (n->left.np != NULL){
        freeall(n->left.np);
    } 
    if (n->right.np != NULL){
        freeall(n->right.np);
    }
    if (n->third.np != NULL){
        freeall(n->third.np);
    }
    free(n);
}

int execute(struct nnode* n) 
{ 
  if (n == NULL) 
    return 0; 

  switch(n->oper) 
    { 
    case VAR: 
        return sym_table[n->left.value]; 
    case INT: 
        return n->left.value; 
    case WHILE: 
        while(execute(n->left.np)) 
        {
            execute(n->right.np);
        } 
        return 0; 
    case IF: 
        if (execute(n->left.np)) 
        {
            execute(n->right.np); 
        }
        else 
        {
            if (n->third.np != NULL)
            {
                execute(n->third.np); 
            } 
        }
        return 0; 
    case PRINT:
        printf("%d\n", execute(n->left.np)); 
        return 0; 
    case ';': 
        execute(n->left.np);        
        return execute(n->right.np);
    case '=':         
        return sym_table[n->left.value] = execute(n->right.np); 
    case '+': 
        return execute(n->left.np) + execute(n->right.np); 
    case '-': 
        return execute(n->left.np) - execute(n->right.np); 
    case '*': 
        return execute(n->left.np) * execute(n->right.np); 
    case '/': 
        return execute(n->left.np) / execute(n->right.np); 
    case '<': 
        return execute(n->left.np) < execute(n->right.np); 
    case '>': 
        return execute(n->left.np) > execute(n->right.np); 
    case GE: 
        return execute(n->left.np) >= execute(n->right.np); 
    case LE: 
        return execute(n->left.np) <= execute(n->right.np); 
    case NE: 
        return execute(n->left.np) != execute(n->right.np); 
    case EQ: 
        return execute(n->left.np) == execute(n->right.np); 
    } 
}