#ifndef FIRST_INTERPRETER_H
#define FIRST_INTERPRETER_H

static int sym_table[26];

struct inode 
{
    int value;
    struct nnode* np;
}; 

struct nnode
{
    int oper;
    struct inode left, right, third;
};

struct nnode* nalloc();

struct nnode* leaf(int type, int val);

struct nnode *node(int op, struct nnode* left, struct nnode* right);

struct nnode *triple(int op, struct nnode* left, struct nnode* right, struct nnode* third);

void freeall(struct nnode* n);

int execute(struct nnode* n);

#endif      //!FIRST_INTERPRETER_H included