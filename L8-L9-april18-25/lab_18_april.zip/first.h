#define NNULL ((NODE*)0)

typedef struct inode 
{
    int value;
    struct nnode* np;
} ITEM; 

typedef struct nnode
{
    int oper;
    struct inode left, right, third;
} NODE;

struct nnode* nalloc(){
    struct nnode* np = (struct nnode*) malloc(sizeof(struct nnode));
    if (np == NNULL){
        yyerror("Out of Memory");
    }
    return np;
}

struct nnode* leaf(int type, int val){
    struct nnode* np = nalloc();
    np->oper = type;
    np->left.value = val;
    np->left.np = NNULL;
    np->right.np = NNULL;
    np->third.np = NNULL;
    return np;
}

struct nnode *node(int op, struct nnode* left, struct nnode* right)
{
	struct nnode *np = nalloc();
	np->oper = op;
	np->left.np = left;
	np->right.np = right;
	np->third.np = NNULL;
	return np;
}

struct nnode *triple(int op, struct nnode* left, struct nnode* right, struct nnode* third)
{
	struct nnode *np = nalloc();
	np->oper = op;
	np->left.np = left;
	np->right.np = right;
	np->third.np = third;
	return np;
}

